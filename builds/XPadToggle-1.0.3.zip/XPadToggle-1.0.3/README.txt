XPadToggle — How to run

1) Install ViGEmBus (virtual controller driver) once. Reboot after install.
2) Extract this zip:
   - Best: use 7-Zip → “Extract to XPadToggle\”, OR
   - Right-click zip → Properties → Unblock → OK → then Extract All…
3) Open the extracted XPadToggle folder → run XPadToggle.exe
4) If you see “Windows protected your PC”: click More info → Run anyway
5) If Defender deletes it:
   - Windows Security → Virus & threat protection → Protection history → Allow on device
   - Or add a temporary folder exclusion for the extracted XPadToggle folder.

Edit ToggleConfig.ini to change timings/hotkeys/guard. Keep it next to XPadToggle.exe.
